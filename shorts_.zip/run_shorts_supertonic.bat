@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
py -3.11 shorts_novel_maker_supertonic.py
if errorlevel 1 (
  echo Python 실행 오류가 있습니다. 필요한 패키지 또는 설치 상태를 확인하세요.
  pause
)
